﻿Imports System
Imports System.IO
Imports System.Net
Imports System.Security.Principal
Imports System.Text
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        RichTextBox3.Visible = False

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RichTextBox3.Visible = True
        Dim hosts As String = "C:\Windows\System32\drivers\etc\hosts"
        Dim hostsTxt As String = "C:\Windows\System32\drivers\etc\hosts"
        'Dim hosts As String = "C:\Users\david\Desktop\david\hosts"
        'Dim hostsTxt As String = "C:\Users\david\Desktop\david\hosts.txt"

        Dim final As String = "C:\Windows\System32\drivers\etc\hosts.txt"
        'Dim final As String = "C:\Users\david\Desktop\david\hostsFinal.txt"
        Dim correcto As Boolean = False
        Dim linea As String

        Dim ficheroHostsTxt As StreamWriter
        Dim reader As StreamReader = New StreamReader(hosts)

        Dim address As String = "https://raw.githubusercontent.com/pookdeveloper/HostsPublicidad/master/webs.txt"
        Dim client As WebClient = New WebClient()
        Dim reader2 As StreamReader = New StreamReader(client.OpenRead(address))


        Dim identity = WindowsIdentity.GetCurrent()
        Dim principal = New WindowsPrincipal(identity)
        Dim isElevated As Boolean = principal.IsInRole(WindowsBuiltInRole.Administrator)


        If isElevated Then
            Try
                If File.Exists(final) Then
                    File.Delete(final)
                End If
                'Creamos el fichero a concatenar los datos

                ficheroHostsTxt = New StreamWriter(final)

                Do While (reader.Peek() >= 0)
                    linea = reader.ReadLine()
                    'Por cada linea la añadimos
                    If linea = "### INI_POOKDEVELOPER ###" Then
                        correcto = False
                        Exit Do ' Salimos del bucle no queremos mas lectura!
                    End If
                    If correcto = False Then
                        ficheroHostsTxt.WriteLine(linea)
                    End If
                Loop
                reader.Close() ' Cerramos conexion


                'Leemos el fichero WEB
                'Por cada linea la añadimos
                Do While reader2.Peek() >= 0
                    linea = reader2.ReadLine()
                    ficheroHostsTxt.WriteLine(linea)
                Loop
                reader2.Close() ' Cerramos conexion
                ficheroHostsTxt.Close() ' Cerramos conexion


                'Borramos el antiguo y Renombramos
                File.Delete(hosts)
                FileSystem.Rename(final, hosts)
                RichTextBox3.Visible = False
                MsgBox("Finalizado Correctamente")


            Catch ex As Exception
                reader.Close()
                reader2.Close()

                Try
                    ficheroHostsTxt.Close()
                Catch ex2 As Exception
                End Try

                RichTextBox3.Visible = False
                MsgBox(ex.Message.ToString)
                'MessageBox.Show("Algo ha ocurrido," & ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            RichTextBox3.Visible = False
            MsgBox("Ejecutalo en modo administrador")
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        RichTextBox3.Visible = True
        Dim identity = WindowsIdentity.GetCurrent()
        Dim principal = New WindowsPrincipal(identity)
        Dim isElevated As Boolean = principal.IsInRole(WindowsBuiltInRole.Administrator)

        If isElevated Then
            Dim hosts As String = "C:\Windows\System32\drivers\etc\hosts"
            Dim hostsTxt As String = "C:\Windows\System32\drivers\etc\hosts"
            'Dim hosts As String = "C:\Users\david\Desktop\david\hosts"
            'Dim hostsTxt As String = "C:\Users\david\Desktop\david\hosts.txt"

            Dim final As String = "C:\Windows\System32\drivers\etc\hosts.txt"
            'Dim final As String = "C:\Users\david\Desktop\david\hostsFinal.txt"
            Dim correcto As Boolean = False
            Dim linea As String

            Dim ficheroHostsTxt As StreamWriter
            Dim reader As StreamReader = New StreamReader(hosts)

            Try
                If File.Exists(final) Then
                    File.Delete(final)
                End If
                'Creamos el fichero a concatenar los datos
                ficheroHostsTxt = New StreamWriter(final)
                Do While (reader.Peek() >= 0)
                    linea = reader.ReadLine()
                    'Por cada linea la añadimos
                    If linea = "### INI_POOKDEVELOPER ###" Then
                        correcto = False
                        Exit Do ' Salimos del bucle no queremos mas lectura!
                    End If
                    If correcto = False Then
                        ficheroHostsTxt.WriteLine(linea)
                    End If
                Loop
                reader.Close() ' Cerramos conexion
                ficheroHostsTxt.Close() ' Cerramos conexion

                'Borramos el antiguo y Renombramos
                File.Delete(hosts)
                FileSystem.Rename(final, hosts)
                RichTextBox3.Visible = False
                MsgBox("Finalizado Correctamente")

            Catch ex As Exception
                reader.Close()

                Try
                    ficheroHostsTxt.Close()
                Catch ex2 As Exception

                End Try


                RichTextBox3.Visible = False
                MsgBox(ex.Message.ToString)
                'MessageBox.Show("Algo ha ocurrido," & ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            RichTextBox3.Visible = False
            MsgBox("Ejecutalo en modo administrador")
        End If



    End Sub
End Class
